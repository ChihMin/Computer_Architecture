#ifndef TESTBENCH_H
#define TESTBENCH_H

namespace Simulator{
	void testbench();
	void judge(int x ,int y);
}

#endif

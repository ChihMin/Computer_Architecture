#ifndef decoder_h
#define decoder_h



    void decodeInstructions(FILE* R);
    void decodeData(FILE* R);


#endif
